# Bus Pass Management System (MERN)

A red-and-pink student bus pass portal with:
- Student registration and login
- Student dashboard
- Apply for a pass with Bonafide, ID card and passport photo uploads
- My Applications and application status tracking
- Admin login and dashboard
- Admin can view student/application details and approve or reject applications
- Approved pass details and printable pass view
- MongoDB persistence, JWT authentication, password hashing and role-based access

## Requirements
- Node.js 18+
- MongoDB Community Server running locally, or a MongoDB Atlas connection string
- npm

## 1. Backend setup
```bash
cd server
npm install
```
Create `server/.env` by copying `.env.example`, then set your MongoDB URI and a long JWT secret.

```bash
npm run seed:admin
npm run dev
```
The API runs at `http://localhost:5000`.

Default seeded admin (change immediately after first login):
- Email: `admin@buspass.local`
- Password: `Admin@12345`

## 2. Frontend setup
Open another terminal:
```bash
cd client
npm install
npm run dev
```
Open the Vite URL shown (normally `http://localhost:5173`).

## 3. Student workflow
1. Register a student account.
2. Log in.
3. Open **Apply for Pass**, complete personal/college/route details and upload the three required documents.
4. Open **My Applications** or **Track Status** to see Pending / Approved / Rejected.
5. When approved, open the application and use **Print Pass**.

## 4. Admin workflow
1. Log in using the seeded admin credentials.
2. Open **Manage Applications**.
3. Review the student's details and uploaded documents.
4. Select **Approve** or **Reject**. A rejection reason is required.
5. The student can see the updated status in their dashboard and tracking page.

## Route validation
The starter app includes a sample route stop list in `server/src/config/routes.js`. Update it to match your actual ST bus routes. The API rejects applications whose start/end stops are not a valid pair in the configured route list.

## Uploads
Uploaded documents are stored in `server/uploads/` and served from `/uploads`. For production, use private object storage and signed URLs rather than a public local uploads folder.

## Important production notes
- Replace the seeded admin password and remove/secure the seed credentials.
- Use HTTPS, strong secrets, rate limiting, audit logging, malware scanning and private document storage.
- Configure CORS to your deployed frontend URL.
- Add email/SMS notifications and payment integration only if required.
- This is a starter project; test it with your institution's actual route, document and approval policies before deployment.
