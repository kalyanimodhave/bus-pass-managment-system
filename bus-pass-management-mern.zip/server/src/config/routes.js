// Replace these sample routes/stops with the official ST route data for your area.
export const routes = [
  { name: 'Pimpri - Shivajinagar', stops: ['Pimpri', 'Kasarwadi', 'Phugewadi', 'Dapodi', 'Khadki', 'Shivajinagar'] },
  { name: 'Nigdi - Swargate', stops: ['Nigdi', 'Akurdi', 'Chinchwad', 'Pimpri', 'Kasarwadi', 'Swargate'] },
  { name: 'Hadapsar - Pune Station', stops: ['Hadapsar', 'Magarpatta', 'Fatima Nagar', 'Camp', 'Pune Station'] }
];

export function isValidJourney(start, end) {
  return routes.some(route => {
    const a = route.stops.indexOf(start);
    const b = route.stops.indexOf(end);
    return a !== -1 && b !== -1 && a < b;
  });
}
